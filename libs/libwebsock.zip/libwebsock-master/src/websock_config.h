/* src/websock_config.h.  Generated from websock_config.h.in by configure.  */
#ifndef WEBSOCK_CONFIG_H
#define WEBSOCK_CONFIG_H 1

#define WEBSOCK_PACKAGE_STRING "libwebsock 1.0.7"
#define WEBSOCK_PACKAGE_VERSION "1.0.7"
#define WEBSOCK_PACKAGE_NAME "libwebsock"
#define WEBSOCK_HAVE_SSL 1

#endif
